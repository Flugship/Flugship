document.querySelector("form").addEventListener("submit", function(e) {
    e.preventDefault();
    alert("Thanks for your message! This form is just a demo.");
});
